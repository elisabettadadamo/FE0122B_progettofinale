import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, AbstractControl} from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';
import { Utenti } from 'src/app/models/utenti';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
	item: any;
	form!: FormGroup;
	user!: Utenti;
  constructor(private fb: FormBuilder, private authService: AuthService, private router: Router) { }

  salva(DatiForm: { value: any; }) {
		console.log(0);
		console.log(DatiForm.value);
		this.item = DatiForm.value;
		this.authService.login(this.item).subscribe(res => {
			console.log(res);
			this.user = res;
			localStorage.setItem('utentecorrente', JSON.stringify(this.user));
			this.router.navigate(['/utenti']);
		});
	}

  ngOnInit(): void {
    console.log('ngOnInit');
		this.InizializzaForm();
  }
	InizializzaForm() {
		console.log('InizializzaForm');
		this.form = this.fb.group({
			username: new FormControl('', [Validators.required]),
			password: new FormControl('', [Validators.required])
		});
		this.form.controls['username'].setValue('');
		this.form.controls['password'].setValue('');
	}
  controlloForm(nome:string){
    return this.form.get(nome) as AbstractControl;
  }

  controlloErrori(nome:string, error: string){
    return this.form.get(nome)?.errors![error];
  }
}
