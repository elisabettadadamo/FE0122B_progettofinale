import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators,AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  form!: FormGroup;
  user ={username:'', password:'', email:'', role: ['']};
  constructor(private fb: FormBuilder, private authSrv: AuthService, private router: Router) { }

  cSalva(DatiForm: { value: { roles:any; username: string; password: string; email: string; }; }) {
		console.log(0);
		console.log(DatiForm.value);


		this.user.username = DatiForm.value.username;
		this.user.password = DatiForm.value.password;
		this.user.email = DatiForm.value.email;
    this.user.role.splice(0,1);
    this.user.role.push(DatiForm.value.roles)

		this.authSrv.signUp(this.user).subscribe(res => {
			console.log(res);
			this.router.navigate(['/login']);
		});
	}

  ngOnInit(): void {
    this.InizializzaForm();

  }

  InizializzaForm() {
		console.log('InizializzaForm');
		this.form = this.fb.group({
			username: new FormControl('', [Validators.required]),
			password: new FormControl('', [Validators.required]),
			email: new FormControl('', [Validators.required]),
			roles: new FormControl(),
		});
		this.form.controls['username'].setValue('');
		this.form.controls['password'].setValue('');
	}
  controlloForm(nome:string){
    return this.form.get(nome) as AbstractControl;
  }
  controlloErrori(nome:string, error: string){
    return this.form.get(nome)?.errors![error];
  }
}
