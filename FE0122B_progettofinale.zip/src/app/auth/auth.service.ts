import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Utenti } from '../models/utenti';
import { BehaviorSubject, tap } from 'rxjs';
import { Router } from '@angular/router';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  pathApi: string;

  timeoutlogout: any;
  private authSubj= new BehaviorSubject<null | Utenti>(null);

  user$ = this.authSubj.asObservable()

  constructor(private http: HttpClient, private router: Router) {

    this.pathApi = environment.pathApi;
   }

   getAll(p: number){
     console.log('getAll');
     return this.http.get<any>(this.pathApi + '/api/users?page=' + p + '&size=20&sort=id,ASC');
   }

   signUp(item: any){
     console.log(item);
     return this.http.post<any>(this.pathApi + '/api/auth/signup', item).pipe(catchError(this.trovaErr));;
   }

   login(item: any){
     console.log(item);
     return this.http.post<any>(this.pathApi + '/api/auth/login', item).pipe(
      tap((data) => {
        console.log(data);
        this.authSubj.next(data);
        localStorage.setItem('user', JSON.stringify(data));
      }),
      catchError(this.trovaErr)
    );;
   }

    get isLogged(): boolean {
     return localStorage.getItem('utentecorrente')!= null;
    }

   logout(){

     localStorage.removeItem('utentecorrente')
     this.router.navigate([''])
     if(this.timeoutlogout){
       clearTimeout(this.timeoutlogout)
     }
   }

   private trovaErr(err: any) {
    switch (err.error) {
      case 'Email and password are required':
        return throwError('ERRORE: Email e password sono obbligatorie!');
        break;
      case 'Email already exists':
        return throwError('ERRORE: Utente già registrato!');
        break;
      case 'Email format is invalid':
        return throwError("ERRORE: Formato dell'email non valido!");
        break;
      case 'Cannot find user':
        return throwError("ERRORE: L'utente non esiste!");
        break;
      default:
        return throwError('ERRORE! Compilare correttamente i campi');
        break;
    }
  }

}
