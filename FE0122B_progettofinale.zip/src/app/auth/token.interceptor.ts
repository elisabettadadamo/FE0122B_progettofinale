import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, tap, finalize } from 'rxjs';
import { AuthService } from './auth.service';
import { environment } from 'src/environments/environment';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
 token: string;
 tenant:string;
  constructor(private authSrv: AuthService) {
    this.token = environment.adminToken;
    this.tenant=environment.adminTenant;
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let ok: string;

    let authReq: HttpRequest<any>= req.clone({headers: req.headers.set("Authorization", 'Bearer '+ this.token).set("X-TENANT-ID", this.tenant)});
    return next.handle(authReq).pipe(tap(event=>{
      ok= event instanceof HttpResponse ? 'succeded' : ''
    },
    error=>{}
    ),
    catchError((error: HttpErrorResponse)=>{
      return throwError(error);
    }),
    finalize(()=>{

    })
    );
  }
}
