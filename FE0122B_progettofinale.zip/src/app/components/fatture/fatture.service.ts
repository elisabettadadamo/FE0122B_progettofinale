import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class FattureService {
  pathApi: string;

  constructor(private http: HttpClient) {
    this.pathApi = environment.pathApi;
   }
   getAll(p: number){
    console.log('getAll')
    return this.http.get<any>(this.pathApi + '/api/fatture?page=' + p + '&size=20&sort=id,ASC');
   }
   getById(id: number){
    return this.http.get<any>(this.pathApi + '/api/fatture/' + id);
  }
  getByCliente(id: number, p:number){
    return this.http.get<any>(this.pathApi + '/api/fatture/cliente/' + id + '?page=' + p + '&size=20&sort=id,ASC');
  }
  delete(id: number){
    return this.http.delete<any>(this.pathApi + '/api/fatture/' + id);
  }
  Salva(id: number, item: any) {
		if (id === 0) {
			return this.http.post<any>(this.pathApi + '/api/fatture', item);
		} else {
			return this.http.put<any>(this.pathApi + '/api/fatture/' + id, item);
		}
  }
  getAllstatofattura(p:number){
     return this.http.get<any>(this.pathApi + '/api/statifattura?page=' + p + '&size=20&sort=id,ASC');
  }
}
