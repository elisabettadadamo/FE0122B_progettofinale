import { Component, OnInit } from '@angular/core';
import { FattureService } from '../fatture.service';
import { Fattura } from 'src/app/models/fattura';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-listafatture',
  templateUrl: './listafatture.component.html',
  styleUrls: ['./listafatture.component.scss']
})
export class ListafattureComponent implements OnInit {
  fatture!: Fattura[];
  res: any;
  idCliente!: number;
  constructor(private fattSrv: FattureService, private router: Router,private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe(params=>{
      this.idCliente = +params['id'];
      this.Carica()
    })
  }
  Carica(){
    if(this.idCliente){
     this.fattSrv.getByCliente(this.idCliente,0).subscribe(c=>{
       this.res = c;
       this.fatture = c.content;
     });
    }else{
    this.fattSrv.getAll(0).subscribe(c=>{
      this.res = c;
      this.fatture = c.content;
    })
  }
  }
  pagine(p: number){
  if(this.idCliente){
    this.fattSrv.getByCliente(this.idCliente, p).subscribe(resp=>{
      this.res = resp;
      this.fatture= resp.content;
    });
 }else{
   this.fattSrv.getAll(p).subscribe(c=>{
     this.res= c;
     this.fatture = c.content;
   });
  }

 }
 conta(i: number){
  return new Array(i);
}

confirmDelete(name: number, id: number, i: number) {
 if (confirm("Sei sicuro di voler eliminare la fattura?")) {

   this.fattSrv.delete(id).subscribe(c => {
     console.log(c);
     this.fatture.splice(i, 1);
   });
 }
}
}
