import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth/auth.service';
import { Utenti } from 'src/app/models/utenti';

@Component({
  selector: 'app-utenti',
  templateUrl: './utenti.component.html',
  styleUrls: ['./utenti.component.scss']
})
export class UtentiComponent implements OnInit {
  users!: Array<Utenti>
  res: any
  constructor(private authSrv: AuthService) { }

  ngOnInit(): void {
    this.carica()
  }

  carica(){
    this.authSrv.getAll(0).subscribe(c=>{
      this.res = c;
      this.users = c.content;
    });
  }

  pagine(p: number){
     this.authSrv.getAll(p).subscribe(resp=>{
       this.res = resp;
       this.users= resp.content
     });
  }

  conta(i: number){
    return new Array(i);
  }
}
