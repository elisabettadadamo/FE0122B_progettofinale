import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth/auth.service';
import { Utenti } from 'src/app/models/utenti';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  user!: Utenti
  isLogged: any;

  constructor(private authSrv: AuthService) { }

  ngOnInit(): void {
   this.isLogged = localStorage.getItem('utentecorrente');

  }

  utenteLoggato(): boolean{
    return localStorage.getItem('utentecorrente')!= null;
  }

  logout(){
    this.authSrv.logout();

  }
}
