import { Component, OnInit } from '@angular/core';
import { ClientiService } from '../clienti.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Cliente } from 'src/app/models/cliente';

@Component({
  selector: 'app-listaclienti',
  templateUrl: './listaclienti.component.html',
  styleUrls: ['./listaclienti.component.scss']
})
export class ListaclientiComponent implements OnInit {
  clienti!: Cliente[];
  res: any;
  form!: FormGroup;
  constructor(private cliSrv: ClientiService, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.carica();
    this.InizializzaForm();
  }

  carica(){
    this.cliSrv.getAll(0).subscribe(c=>{
      this.res = c;
      this.clienti = c.content;
    });
  }
  InizializzaForm() {
		this.form = this.fb.group({
			Cerca: new FormControl()
		});

  }

  pagine(p: number){
    this.cliSrv.getAll(p).subscribe(resp=>{
      this.res = resp;
      this.clienti= resp.content
    });
 }

 conta(i: number){
   return new Array(i);
 }

 confirmDelete(name: string, id: number, i: number) {
  if (confirm("Sei sicuro di voler eliminare " + name)) {

    this.cliSrv.delete(id).subscribe(c => {
      console.log(c);
      this.clienti.splice(i, 1);
    });
  }
}
}
