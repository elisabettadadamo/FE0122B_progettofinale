import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { RouterModule, Route } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { AuthModule } from './auth/auth.module';
import { AuthGuard } from './auth/auth.guard';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HomeComponent } from './components/home/home.component';
import { UtentiComponent } from './components/utenti/utenti.component';
import { ListaclientiComponent } from './components/clienti/listaclienti/listaclienti.component';
import { ListafattureComponent } from './components/fatture/listafatture/listafatture.component';
import { ModificaclienteComponent } from './components/clienti/modificacliente/modificacliente.component';
import { ModificafattureComponent } from './components/fatture/modificafatture/modificafatture.component';

const routes: Route[] = [
  {
    path:'',
    component: HomeComponent
  },
  {
    path: 'utenti',
    component: UtentiComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'listaclienti',
    component: ListaclientiComponent,
    canActivate: [AuthGuard]
  },
  {
    path:'modificacliente/:id',
    component:ModificaclienteComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'listafatture',
    component: ListafattureComponent,
    canActivate: [AuthGuard]
  },
  {
    path:'listafatture/cliente/:id',
    component:ListafattureComponent,
    canActivate:[AuthGuard]
  },
  {
  path:'listafatture/:id',
  component:ModificafattureComponent,
  canActivate: [AuthGuard]
  },
  {
    path:'listafatture/:id/:idCliente',
    component:ModificafattureComponent,
    canActivate: [AuthGuard]
  }


]

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    UtentiComponent,
    ListaclientiComponent,
    ListafattureComponent,
    ModificaclienteComponent,
    ModificafattureComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    AuthModule,
    RouterModule.forRoot(routes)

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
